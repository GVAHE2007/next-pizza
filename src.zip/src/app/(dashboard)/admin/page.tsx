export default function DashboardPage() {
    return (
        <>

            <h1>Barev Admin</h1>

        </>
    )
}