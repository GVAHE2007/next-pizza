import React from "react";
import { cn } from "@/lib/utils";
import { Button } from "../ui";
import { Basket } from "./basket";

interface Props {
  className?: string;
}

export const BasketButton: React.FC<Props> = (props) => {
  const { className } = props;
  return (
    <Basket>
      <Button className={cn("", className)}>
        <span>520$</span>|<span>3</span>
      </Button>
    </Basket>
  );
};
