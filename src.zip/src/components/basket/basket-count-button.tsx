import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from '../ui';
import { Minus, Plus } from 'lucide-react';

interface Props {
    className?: string;
    increment: () => Promise<void>;
    decrement: () => Promise<void>;
    count: number
}

export const BasketCountButton: React.FC<Props> = (props) => {
    const { className, increment, decrement, count } = props;
    return (
        <div className={cn("", className)}>
            <Button onClick={() => decrement()}><Minus /></Button>
            <span>{count}</span>
            <Button onClick={() => increment()}><Plus /></Button>
        </div>
    );
}