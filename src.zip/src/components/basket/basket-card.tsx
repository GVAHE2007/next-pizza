import React from 'react';
import { cn } from '@/lib/utils';
import { Title } from '../title';
import { X } from 'lucide-react';
import { BasketCountButton } from './basket-count-button';

interface Props {
    className?: string;
    imgUrl: string;
    title: string;
    detalis: string;
    price: number;
    count: number;
    increment: () => Promise<void>;
    decrement: () => Promise<void>;
    remove: () => Promise<void>;
}

export const BasketCard: React.FC<Props> = (props) => {
    const { className, count, decrement, increment, remove, imgUrl, title, detalis, price } = props;
    return (
        <div className={cn("", className)}>
            <img src={imgUrl} alt="" />
            <div>
                <Title size={'m'}>
                    {title}
                </Title>
                <p>{detalis}</p>
            </div>

            <div>
                <span>{price}</span>
                <BasketCountButton increment={increment} decrement={decrement} count={count} />
            </div>

            <button onClick={remove}><X /></button>
        </div>
    );
}