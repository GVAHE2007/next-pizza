export enum ApiRoutes {
    INGREDIENTS = "/ingredients",
    PRODUCTS = "/products",
    BASKET = "/basket",
}